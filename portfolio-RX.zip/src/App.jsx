import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold">Hi, I'm Rich 😊</h1>
      <p className="text-lg mt-2">I'm a creative full stack developer</p>
      <button className="mt-4 px-6 py-2 bg-pink-400 hover:bg-pink-500 text-white rounded-full shadow">
        LET'S TALK
      </button>
    </div>
  );
}